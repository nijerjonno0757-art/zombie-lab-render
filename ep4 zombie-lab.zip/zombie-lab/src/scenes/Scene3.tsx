import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Who, speakingNow} from '../config';
import {Key, CamView, Shake, useCam, useT} from '../lib/camera';
import {lerp, pop, ramp, track, win} from '../lib/anim';
import {Character, Expr, toWorld} from '../components/Character';
import {Door, LabBG, Workstation, CountScreen} from '../components/Lab';
import {MomoBox, Warn} from '../components/Props';
import {Alarm, Bubble} from '../components/Overlays';
import {FY, SC} from './Scene1';

export const WW = 2160;
const DOOR_X = 1700;
const ARM_UP = 100;

// ---- সুমাইয়ার পোজ (সিন ৩ ও ৪ দুটোতেই ব্যবহৃত) ----
export const sumPose = (t: number) => ({
  x: track(t, [[61.3, 460], [61.7, 460], [64.1, 1560]]),
  y: 1480, s: SC,
  lie: track(t, [[81.68, 0], [83.2, 1], [84.6, 0.95], [85.6, 0.55], [95.9, 0.55], [99.6, 0.12]]),
});
const sumHeadTilt = (t: number) => track(t, [[85, 0], [86, -14], [94.5, -14], [95.4, 28], [96.7, 28], [98.4, 0]]);
export const headPt = (t: number): [number, number] => toWorld(sumPose(t), 0, -495);
export const eyePt = (t: number): [number, number] => toWorld(sumPose(t), 0, -505);
export const scratchPt = (): [number, number] => {
  const a = (ARM_UP * Math.PI) / 180;
  return toWorld(sumPose(87), -75 - 105 * Math.sin(a), -376 + 105 * Math.cos(a));
};

const ahanaX = (t: number) => track(t, [[61.3, 220], [61.55, 220], [64.0, 1400], [73.16, 1400], [74.1, 1290], [81.0, 1290], [82.4, 1120]]);
const prabhaX = (t: number) => track(t, [[61.3, 700], [61.9, 700], [64.3, 1150], [76.6, 1150], [78.2, 1640], [88.0, 1640], [90.0, 1780]]);
const prabhaY = (t: number) => track(t, [[76.5, 1480], [76.62, 1545], [78.4, 1545], [79.2, 1500]]);

// জম্বি যে ভেতরে ঢোকে (৬৯.৯৮s) ও পরে ঝাঁপ দেয়, ধাক্কা খেয়ে দরজায় ফেরে (৭৫.৪s)
const zPose = (t: number) => {
  const x = track(t, [[69.98, 1940], [71.76, 1700], [73.0, 1470], [74.2, 1450], [75.4, 1880]]);
  const yb = track(t, [[69.98, 1298], [71.0, 1298], [71.76, 1470], [74.2, 1470], [75.4, 1298]]);
  const arc = -170 * Math.sin(Math.PI * ramp(t, 71.76, 73.0)) - 90 * Math.sin(Math.PI * ramp(t, 74.2, 75.4));
  const s = track(t, [[69.98, 0.7], [71.76, 0.85], [74.2, 0.85], [75.4, 0.7]]);
  const tilt = track(t, [[71.76, 0], [72.4, -18], [73.0, 0], [74.2, 0], [74.7, 60], [75.4, 0]]);
  return {x, y: yb + arc, s, tilt};
};

const CROWD: [number, number, number, number][] = [
  [1790, 1215, 0.46, 0], [1880, 1215, 0.5, 1], [1960, 1220, 0.46, 2], [2050, 1215, 0.48, 3], [2100, 1222, 0.45, 0],
  [1740, 1255, 0.58, 2], [1840, 1255, 0.6, 3], [1950, 1258, 0.58, 0], [2040, 1255, 0.6, 1],
  [1770, 1296, 0.7, 1], [1900, 1298, 0.72, 2], [2020, 1296, 0.7, 3],
];

export const roomAnchor = (t: number) => (w: Who): [number, number] => {
  if (w === 'ahana') return [ahanaX(t), 1480 - 595 * SC];
  if (w === 'prabha') return [prabhaX(t), prabhaY(t) - 595 * SC];
  return toWorld(sumPose(t), 0, -600);
};

/** সিন ৩ + ৪-এর শেয়ার্ড দৃশ্য */
export const Room3: React.FC<{t: number}> = ({t}) => {
  const sp = (w: Who) => speakingNow(w, t);
  const open = track(t, [[64.5, 0], [65.5, 1], [77.2, 1], [78.4, 0]]);
  const thump = t > 79 ? Math.max(0, Math.sin(t * 3.1) * Math.sin(t * 7.7)) * 3 * Math.sin(t * 50) : 0;
  const z = zPose(t);
  const zFree = t >= 69.98 && t < 75.4;
  const zCrowd = t >= 75.4;

  // --- অহনা ---
  const aRun = (t > 61.55 && t < 64.05) || (t > 81 && t < 82.4) ? t * 14 : undefined;
  const aExpr: Expr = t < 64.6 ? 'scared' : t < 69.98 ? 'shock' : t < 73.16 ? 'scared' : t < 74.4 ? 'shock' : t < 81.68 ? 'scared' : 'shock';
  const aArm = t > 69.98 && t < 73.2 ? 100 : 8;
  // --- সুমাইয়া ---
  const sp0 = sumPose(t);
  const sRun = t > 61.7 && t < 64.1 ? t * 14 : undefined;
  const sExpr: Expr = t < 73 ? 'scared' : t < 81.68 ? 'shock' : t < 97 ? 'sad' : t < 105 ? 'scared' : 'neutral';
  const sArmR = track(t, [[73.16, 8], [73.45, 85], [74.2, 85], [74.6, -25], [81.6, -25], [83.2, 40], [85.2, 40], [86.0, ARM_UP]]);
  const sArmL = track(t, [[101.4, 8], [102.0, 75]]);
  const sTremble = t < 73 ? 0.6 : t < 81.68 ? 1.2 : t < 105 ? 2.2 : 0.6;
  // --- প্রভা ---
  const pRun = (t > 61.9 && t < 64.3) || (t > 76.62 && t < 78.3) ? t * 14 : undefined;
  const pExpr: Expr = t < 64.6 ? 'serious' : t < 69.98 ? 'shock' : t < 76.62 ? 'scared' : t < 79.68 ? 'angry' : t < 81.68 ? 'neutral' : t < 87 ? 'shock' : 'sad';
  const pArm = t > 78.3 && t < 79.3 ? 95 : 8;

  const momoDrop = ramp(t, 73.16, 73.6);
  const scratch = ramp(t, 84.9, 86.2);
  const warnV = win(t, 85.6, 87.6, 0.3, 0.3);
  const sc = scratchPt();

  const zombie = (extra: React.ReactNode) => extra;
  return (
    <svg width={WW} height={1920} viewBox={`0 0 ${WW} 1920`} style={{position: 'absolute'}}>
      <LabBG ww={WW} t={t} lights={[540, 1380]} signX={1230} shelfX={60} />
      <Workstation x={790} screen={<CountScreen t={t} />} />
      <Door x={DOOR_X} open={open} shake={thump}>
        {CROWD.map(([x, y, s, v], i) => (
          <Character key={i} kind="zombie" x={x} y={y} s={s} variant={v} seed={i + 5} flip={i % 2 === 0} armR={125} armL={118}
            tremble={0.8} float={3} headTilt={(i % 3 - 1) * 8} tilt={(i % 2 ? 1 : -1) * 3} />
        ))}
        {zCrowd && <Character kind="zombie" x={1880} y={1298} s={0.7} variant={1} seed={30} armR={125} armL={118} tremble={0.8} />}
      </Door>
      {t > 73.16 && <MomoBox x={1610} y={lerp(1380, 1500, momoDrop)} rot={-14 * momoDrop} />}

      <Character kind="ahana" x={ahanaX(t)} y={1480} s={SC} expr={aExpr} talk={sp('ahana')} seed={1} run={aRun} look={[1, 0]}
        armR={aArm} armL={aArm} tilt={track(t, [[73.16, 0], [73.6, -14], [74.4, 0]])} tremble={t > 87 ? 2 : 0.8} sweat={t > 69.98} />
      <Character kind="sumaiya" x={sp0.x} y={sp0.y} s={SC} lie={sp0.lie} expr={sExpr} talk={sp('sumaiya')} seed={2} run={sRun}
        momo={t < 73.16} scratch={scratch} infect={track(t, [[97.0, 0], [101.5, 1]])} headTilt={sumHeadTilt(t)}
        look={t > 85.6 && t < 97 ? [-1, 0.4] : t > 98 ? [0, 0] : [0, 0.8]} armR={sArmR} armL={sArmL} tremble={sTremble} sweat={t > 81.68 && t < 101} />
      {zFree && (
        <Character kind="zombie" x={z.x} y={z.y} s={z.s} tilt={z.tilt} variant={1} seed={30} armR={t > 71.76 ? 150 : 120} armL={t > 71.76 ? 150 : 115}
          run={t < 71.76 ? t * 6 : undefined} runAmp={14} flip={false} />
      )}
      <Character kind="prabha" x={prabhaX(t)} y={prabhaY(t)} s={SC} expr={pExpr} talk={sp('prabha')} seed={3} run={pRun} look={[1, 0]}
        armL={pArm} tilt={t > 79.68 && t < 87 ? 5 : 0} float={t > 79.68 && t < 87 ? 8 : 4} tremble={t > 81.68 ? 1.5 : 0} sweat={t > 79} />
      {warnV > 0 && <Warn x={sc[0] + 70} y={sc[1] - 70 - Math.sin(t * 8) * 5} s={0.9 * pop(t, 85.6, 0.3)} o={warnV} />}
      {zombie(null)}
    </svg>
  );
};

const SP = scratchPt();
const MID94: [number, number] = [(headPt(94)[0] + SP[0]) / 2, (headPt(94)[1] + SP[1]) / 2];
export const KEYS3: Key[] = [
  {t: 61.32, x: 220, y: FY, z: 3.0}, // সিন ২-এর অহনা ক্লোজ-আপ থেকে
  {t: 61.9, x: 480, y: 1060, z: 1.4},
  {t: 63.0, x: 930, y: 1100, z: 1.3}, // ছুটে চলার সাথে প্যান
  {t: 64.3, x: 1380, y: 1100, z: 1.3},
  {t: 64.7, x: 1500, y: 1060, z: 1.5},
  {t: 65.6, x: 1800, y: 980, z: 1.9}, // দরজা খুলতেই জম্বির দল
  {t: 67.7, x: 1830, y: 960, z: 2.3},
  {t: 69.9, x: 1760, y: 1040, z: 1.6},
  {t: 71.4, x: 1600, y: 1100, z: 1.7},
  {t: 72.9, x: 1500, y: 1100, z: 2.0}, // ঝাঁপ
  {t: 73.5, x: 1450, y: 1120, z: 1.8},
  {t: 75.0, x: 1440, y: 1150, z: 1.5},
  {t: 76.5, x: 1400, y: 1150, z: 1.45},
  {t: 78.1, x: 1600, y: 1130, z: 1.7}, // প্রভা দরজা বন্ধ করে
  {t: 79.2, x: 1560, y: 1150, z: 1.55},
  {t: 80.2, x: 1400, y: 1180, z: 1.25},
  {t: 82.4, x: 1400, y: 1260, z: 1.8}, // সুমাইয়া মাটিতে
  {t: 84.8, x: 1380, y: 1260, z: 2.0},
  {t: 86.3, x: SP[0], y: SP[1], z: 3.4}, // হাতের আঁচড়ে ক্লোজ-আপ
  {t: 87.2, x: SP[0] + 10, y: SP[1], z: 3.6},
  {t: 87.85, x: 1120, y: FY, z: 2.7, ease: 'out'}, // অহনা ক্লোজ-আপ
  {t: 89.7, x: 1120, y: FY, z: 2.9},
  {t: 90.3, x: MID94[0], y: MID94[1], z: 2.2},
  {t: 94.0, x: MID94[0], y: MID94[1], z: 2.4},
];
const SHAKES3: Shake[] = [
  {from: 71.9, to: 73.1, amp: 6}, {from: 73.16, to: 74.2, amp: 10}, {from: 78.3, to: 79.0, amp: 14},
];

export const Scene3: React.FC = () => {
  const t = useT();
  const cam = useCam(KEYS3, WW, SHAKES3);
  return (
    <AbsoluteFill>
      <CamView cam={cam}><Room3 t={t} /></CamView>
      <Bubble cam={cam} anchor={roomAnchor(t)} />
      <Alarm level={1} />
    </AbsoluteFill>
  );
};
