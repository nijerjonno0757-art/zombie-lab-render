import React from 'react';
import {AbsoluteFill} from 'remotion';
import {speakingNow, Who} from '../config';
import {Key, CamView, Shake, useCam, useT} from '../lib/camera';
import {pop, track, win} from '../lib/anim';
import {Character, Expr} from '../components/Character';
import {DesktopScreen, LabBG, SecurityFeed, Workstation} from '../components/Lab';
import {Momo, NameBadge, QMark} from '../components/Props';
import {Alarm, Bubble} from '../components/Overlays';

export const SC = 0.85;
export const POS: Record<Who, [number, number]> = {ahana: [220, 1480], sumaiya: [460, 1480], prabha: [700, 1480]};
export const FY = 1100; // ক্লোজ-আপের ফোকাস উচ্চতা
export const headTop = (w: Who): [number, number] => [POS[w][0], POS[w][1] - 595 * SC];

export const KEYS: Key[] = [
  {t: 0, x: 540, y: 1000, z: 1.05},
  {t: 6.6, x: 470, y: 1080, z: 1.5}, // ন্যারেটর: তিনজনের দিকে ধীর পুশ-ইন
  {t: 7.15, x: 220, y: FY, z: 2.6, ease: 'out'}, // অহনা ক্লোজ-আপ
  {t: 9.6, x: 230, y: FY, z: 2.8},
  {t: 10.05, x: 460, y: FY, z: 2.6}, // সুমাইয়া ক্লোজ-আপ
  {t: 15.4, x: 460, y: FY, z: 3.0},
  {t: 16.7, x: 620, y: 1040, z: 1.55}, // ন্যারেটর: প্রভা ও কম্পিউটারের দিকে
  {t: 19.4, x: 780, y: 960, z: 1.9},
  {t: 21.0, x: 930, y: 820, z: 3.4}, // মনিটরে জুম
  {t: 29.5, x: 930, y: 820, z: 3.7},
  {t: 30.55, x: 700, y: FY, z: 2.6, ease: 'out'}, // প্রভা ক্লোজ-আপ
  {t: 32.74, x: 700, y: FY, z: 2.95},
];
const SHAKES: Shake[] = [{from: 29.7, to: 30.1, amp: 7}];

export const Scene1: React.FC = () => {
  const t = useT();
  const cam = useCam(KEYS, 1080, SHAKES);
  const sp = (w: Who) => speakingNow(w, t);
  const sumExpr: Expr = t >= 12.42 && t < 13.3 ? 'laugh' : 'nervous';
  const prabhaExpr: Expr = t < 29.7 ? 'happy' : 'cold';
  const monitorLook: [number, number] = [1, -0.5];
  const iconA = win(t, 7.04, 9.7, 0.25, 0.2);
  const iconM = win(t, 13.8, 15.65, 0.25, 0.2);

  return (
    <AbsoluteFill>
      <CamView cam={cam}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute'}}>
          <LabBG ww={1080} t={t} shelfX={40} signX={540} lights={[270, 810]} />
          <Workstation x={790} screen={t < 21.1 ? <DesktopScreen t={t} /> : <SecurityFeed t={t} />} />

          <Character kind="ahana" x={POS.ahana[0]} y={POS.ahana[1]} s={SC} expr="serious" talk={sp('ahana')} seed={1}
            look={t < 16 ? [1, 0] : monitorLook} armL={track(t, [[7.9, 8], [8.4, 75], [9.6, 75], [10.1, 8]])} tremble={0.3} />
          <Character kind="prabha" x={POS.prabha[0]} y={POS.prabha[1]} s={SC} expr={prabhaExpr} talk={sp('prabha')} seed={3}
            look={t < 16.3 ? [-1, 0] : [1, -0.6]}
            armL={t < 17.2 ? 8 : t < 29.9 ? 38 + Math.sin(t * 14) * 5 : 8} />

          <Character kind="sumaiya" x={POS.sumaiya[0]} y={POS.sumaiya[1]} s={SC} expr={sumExpr} talk={sp('sumaiya')} seed={2} momo sweat={t > 9}
            look={t < 15.6 ? [-1, 0] : monitorLook} tremble={t > 9.5 && t < 16 ? 1.4 : 0.5}
            armR={track(t, [[9.9, 8], [10.3, 60], [15.2, 60], [16, 8]])} armL={track(t, [[9.9, 8], [10.3, 22], [15.2, 22], [16, 8]])} />
          {(['ahana', 'sumaiya', 'prabha'] as Who[]).map((w, i) => (
            <NameBadge key={w} who={w} x={headTop(w)[0]} y={headTop(w)[1] - 30} t={t} at={3.4 + i} until={6.95} />
          ))}
          {iconA > 0 && <QMark x={350} y={960 - Math.sin(t * 5) * 6} s={1.4 * pop(t, 7.04, 0.3)} o={iconA} />}
          {iconM > 0 && <Momo x={548} y={925 - Math.sin(t * 5) * 6} s={1.5 * pop(t, 13.8, 0.3)} o={iconM} />}
        </svg>
      </CamView>
      <Bubble cam={cam} anchor={headTop} />
      <Alarm level={0} />
    </AbsoluteFill>
  );
};
