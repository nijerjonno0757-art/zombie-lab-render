import React from 'react';
import {AbsoluteFill} from 'remotion';
import {speakingNow, Who} from '../config';
import {Key, CamView, Shake, useCam, useT} from '../lib/camera';
import {track} from '../lib/anim';
import {Character, Expr} from '../components/Character';
import {LabBG, Workstation, screenAt2} from '../components/Lab';
import {Alarm, Bubble} from '../components/Overlays';
import {FY, headTop, POS, SC} from './Scene1';

export const KEYS: Key[] = [
  {t: 32.74, x: 700, y: FY, z: 2.95}, // সিন ১-এর শেষ ফ্রেম থেকেই চলতে থাকে
  {t: 34.0, x: 850, y: 900, z: 2.0},
  {t: 36.2, x: 930, y: 820, z: 3.4}, // মনিটরে ফাইল
  {t: 42.0, x: 930, y: 820, z: 3.8},
  {t: 42.8, x: 700, y: 1060, z: 1.5}, // "ব্যর্থ" — তিনজনের প্রতিক্রিয়া
  {t: 45.4, x: 700, y: 1060, z: 1.5},
  {t: 45.9, x: 700, y: FY, z: 2.7, ease: 'out'}, // প্রভা ক্লোজ-আপ
  {t: 49.5, x: 700, y: FY, z: 3.1},
  {t: 51.3, x: 700, y: FY, z: 3.1},
  {t: 52.5, x: 930, y: 820, z: 3.4}, // কাউন্টডাউন জ্বলে ওঠে
  {t: 58.9, x: 930, y: 820, z: 3.7},
  {t: 59.6, x: 220, y: FY, z: 2.7, ease: 'out'}, // অহনা ক্লোজ-আপ (প্যানিক)
  {t: 61.32, x: 220, y: FY, z: 3.0},
];
const SHAKES: Shake[] = [
  {from: 44.26, to: 44.9, amp: 10},
  {from: 54.8, to: 61.3, amp: 5},
];

export const Scene2: React.FC = () => {
  const t = useT();
  const cam = useCam(KEYS, 1080, SHAKES);
  const sp = (w: Who) => speakingNow(w, t);
  const mon: [number, number] = [1, -0.5];
  const pe: Expr = t < 39.5 ? 'happy' : t < 45.54 ? 'serious' : t < 51.3 ? 'scared' : 'shock';
  const ae: Expr = t < 44.26 ? 'serious' : t < 54.8 ? 'shock' : 'scared';
  const se: Expr = t < 44.26 ? 'nervous' : t < 54.8 ? 'shock' : 'scared';
  const panic = t > 54.8;

  return (
    <AbsoluteFill>
      <CamView cam={cam}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute'}}>
          <LabBG ww={1080} t={t} shelfX={40} signX={540} lights={[270, 810]} />
          <Workstation x={790} screen={screenAt2(t)} />
          <Character kind="ahana" x={POS.ahana[0]} y={POS.ahana[1]} s={SC} expr={ae} talk={sp('ahana')} seed={1} look={mon}
            tremble={t > 59.2 ? 3.5 : panic ? 1 : 0.3} sweat={t > 59} />
          <Character kind="prabha" x={POS.prabha[0]} y={POS.prabha[1]} s={SC} expr={pe} talk={sp('prabha')} seed={3}
            look={t > 45.5 && t < 51.3 ? [-1, 0] : [1, -0.6]} tremble={t > 45.5 ? 1.2 : 0}
            armL={t < 44 ? 38 + Math.sin(t * 14) * 5 : track(t, [[45.5, 8], [46.5, 75], [49.4, 75], [50.4, 40], [51.2, 8]])} />

          <Character kind="sumaiya" x={POS.sumaiya[0]} y={POS.sumaiya[1]} s={SC} expr={se} seed={2} momo look={mon}
            tremble={panic ? 2 : 0.5} sweat={t > 44.3} />        </svg>
      </CamView>
      <Bubble cam={cam} anchor={headTop} />
      <Alarm level={track(t, [[54.78, 0], [55.6, 1]])} />
    </AbsoluteFill>
  );
};
