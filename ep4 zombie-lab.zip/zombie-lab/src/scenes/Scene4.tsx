import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Key, CamView, Shake, useCam, useT} from '../lib/camera';
import {ramp, track} from '../lib/anim';
import {Alarm, Bubble} from '../components/Overlays';
import {Room3, WW, eyePt, headPt, roomAnchor, scratchPt} from './Scene3';

const SP = scratchPt();
const mid = (t: number): [number, number] => [(headPt(t)[0] + SP[0]) / 2, (headPt(t)[1] + SP[1]) / 2];
const hk = (t: number, z: number, dy = 0): Key => ({t, x: headPt(t)[0], y: headPt(t)[1] + dy, z});

export const KEYS4: Key[] = [
  {t: 94.0, x: mid(94)[0], y: mid(94)[1], z: 2.4}, // সিন ৩-এর শেষ ফ্রেমের ধারাবাহিকতা
  {t: 95.6, x: mid(95.6)[0], y: mid(95.6)[1], z: 2.4},
  hk(97.0, 3.0, 10), // ধীরে মাথা তোলে — ক্যামেরা মুখে টিল্ট-আপ
  hk(98.0, 3.1, 10),
  hk(99.0, 3.3, 10),
  hk(100.0, 3.4, 10),
  hk(101.7, 3.5, 10),
  hk(104.88, 3.6, 10),
  {t: 109.2, x: eyePt(104.88)[0], y: eyePt(104.88)[1], z: 9.5}, // চোখে এক্সট্রিম জুম
  {t: 110.53, x: eyePt(104.88)[0], y: eyePt(104.88)[1], z: 9.8},
];
const SHAKES4: Shake[] = [{from: 101.7, to: 105, amp: 2}];

export const Scene4: React.FC = () => {
  const t = useT();
  const cam = useCam(KEYS4, WW, SHAKES4);
  const infect = track(t, [[97.0, 0], [101.5, 1]]);
  return (
    <AbsoluteFill>
      <CamView cam={cam}><Room3 t={t} /></CamView>
      <div style={{position: 'absolute', inset: 0, background: '#6dff9c', opacity: infect * 0.07}} />
      <Bubble cam={cam} anchor={roomAnchor(t)} />
      <Alarm level={track(t, [[94, 1], [97, 0.5], [110, 0.4]])} />
      <div style={{position: 'absolute', inset: 0, background: '#000', opacity: ramp(t, 108.9, 110.1)}} />
    </AbsoluteFill>
  );
};
