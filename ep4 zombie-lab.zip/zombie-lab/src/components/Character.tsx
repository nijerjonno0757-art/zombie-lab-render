import React from 'react';
import {useCurrentFrame} from 'remotion';
import {OUT, SW} from '../config';

export type Kind = 'sumaiya' | 'ahana' | 'prabha' | 'mystery' | 'zombie';
export type Expr = 'neutral' | 'happy' | 'nervous' | 'serious' | 'shock' | 'sad' | 'cold' | 'scared' | 'angry' | 'laugh';
export type Pose = {x: number; y: number; s: number; lie?: number; tilt?: number; flip?: boolean};

export type CharProps = {
  kind: Kind; x: number; y: number; s?: number; flip?: boolean;
  expr?: Expr; talk?: boolean; look?: [number, number];
  armR?: number; armL?: number; // কোণ: ০ = ঝুলানো, ৯০ = পাশে সমান্তরাল, ১৮০ = সোজা ওপরে (বাইরের দিকে)
  lie?: number; tilt?: number; tremble?: number; float?: number;
  infect?: number; scratch?: number; momo?: boolean; headTilt?: number;
  run?: number; runAmp?: number; variant?: number; seed?: number; sweat?: boolean;
};

const S = {stroke: OUT, strokeWidth: SW, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
const SKIN: Record<Kind, string> = {sumaiya: '#f2c6a0', ahana: '#e8b98f', prabha: '#d9a77c', mystery: '#e9dfd2', zombie: '#93a98c'};
const PANTS: Record<Kind, string> = {sumaiya: '#3f6fb5', ahana: '#2b2b2b', prabha: '#8b9099', mystery: '#8d9399', zombie: '#55524b'};
const TOP: Record<Kind, string> = {sumaiya: '#f7d96b', ahana: '#1e5a3a', prabha: '#e23d3d', mystery: '#9ba1a8', zombie: '#6b5b4a'};
const HAIR: Record<Kind, string> = {sumaiya: '#1d1d1d', ahana: '#1d1d1d', prabha: '#2a1a14', mystery: '#141414', zombie: '#3a2f28'};
const ZTOP = ['#6b5b4a', '#4f6a7a', '#7a4f55', '#566b46'];
const ZHAIR = ['#2f2723', '#4a3b2e', '#1d1d1d', '#5a5148'];
const SLEEVE: Record<Kind, number> = {sumaiya: 95, ahana: 62, prabha: 146, mystery: 80, zombie: 66};

const BROW: Record<Expr, [number, number]> = {
  neutral: [0, 0], happy: [-4, -6], serious: [16, 5], shock: [-4, -14], sad: [-16, -2],
  cold: [7, 4], scared: [-18, -8], angry: [24, 7], nervous: [-14, -5], laugh: [-6, -6],
};
const MOUTH: Record<Expr, string> = {
  neutral: 'M-18 50 Q0 54 18 50', happy: 'M-28 44 Q0 78 28 44', serious: 'M-16 52 L16 52', cold: 'M-16 52 L16 52',
  sad: 'M-20 60 Q0 40 20 60', nervous: 'M-22 52 Q-11 44 0 52 T22 52', scared: 'M-22 56 Q-11 46 0 56 T22 56',
  angry: 'M-20 60 Q0 42 20 60', shock: '', laugh: '',
};

const mix = (a: string, b: string, p: number) => {
  const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
  const c = (s: number) => Math.round(((pa >> s) & 255) * (1 - p) + ((pb >> s) & 255) * p);
  return `rgb(${c(16)},${c(8)},${c(0)})`;
};

/** ক্যারেক্টারের লোকাল পয়েন্ট → ওয়ার্ল্ড পয়েন্ট (ক্যামেরা ফোকাসের জন্য) */
export const toWorld = (p: Pose, lx: number, ly: number): [number, number] => {
  const th = ((-90 * (p.lie ?? 0)) + (p.tilt ?? 0)) * Math.PI / 180;
  const rx = lx * Math.cos(th) - ly * Math.sin(th);
  let ry = lx * Math.sin(th) + ly * Math.cos(th);
  ry += -75 * (p.lie ?? 0);
  return [p.x + (p.flip ? -1 : 1) * p.s * rx, p.y + p.s * ry];
};

export const Character: React.FC<CharProps> = (p) => {
  const fr = useCurrentFrame();
  const {kind, x, y, s = 1, flip = false, expr = 'neutral', talk = false, look = [0, 0], lie = 0, tilt = 0,
    tremble = 0, float = 4, momo = false, headTilt = 0, run, runAmp = 32, variant = 0, seed = 0, sweat = false, scratch = 0} = p;
  const infect = p.infect ?? (kind === 'zombie' ? 1 : 0);
  const sd = seed * 17;
  const bob = Math.sin((fr + sd) / 20) * float;
  const rb = run !== undefined ? -Math.abs(Math.sin(run)) * 12 : 0;
  const tx = tremble ? Math.sin((fr + sd) * 2.7) * tremble : 0;
  const ty = tremble ? Math.cos((fr + sd) * 3.3) * tremble * 0.6 : 0;
  const blink = (fr + sd) % 105 < 4;
  const shape = talk ? [0, 1, 2, 1, 2, 0, 2, 1][Math.floor((fr + sd) / 3) % 8] : 0;

  const z = kind === 'zombie';
  const skin = z ? mix(SKIN.zombie, '#7f9479', (variant % 4) * 0.12) : mix(SKIN[kind], '#aebba8', infect * 0.55);
  const pants = PANTS[kind];
  const top = z ? ZTOP[variant % 4] : TOP[kind];
  const hair = z ? ZHAIR[variant % 4] : HAIR[kind];
  const shoe = kind === 'ahana' ? '#1c1c1c' : kind === 'sumaiya' || kind === 'prabha' ? '#f4f4f4' : skin;
  const legRot = run !== undefined ? Math.sin(run) * runAmp : 0;
  const armsRun = run !== undefined && !z;
  const aR = armsRun ? 22 + Math.sin(run! + Math.PI) * 38 : p.armR ?? 8;
  const aL = armsRun ? 22 + Math.sin(run!) * 38 : p.armL ?? 8;
  const fs = kind === 'ahana' ? 0.9 : 1; // হিজাবের কারণে মুখ একটু ছোট
  const e: Expr = z ? 'angry' : expr;

  // ---------- অংশগুলো ----------
  const leg = (cx: number, rot: number) => (
    <g transform={`rotate(${rot} ${cx} -190)`}>
      <rect x={cx - 22} y={-192} width={44} height={174} rx={22} fill={pants} {...S} />
      {z && <path d={`M${cx - 20} -60 l10 10 l8 -8 l8 12`} fill="none" stroke="#2b2924" strokeWidth={2} />}
      <ellipse cx={cx} cy={-14} rx={36} ry={17} fill={shoe} {...S} />
    </g>
  );

  const arm = (sx: number, rot: number, extra?: React.ReactNode) => (
    <g transform={`translate(${sx} -376) rotate(${rot})`}>
      <rect x={-16} y={-6} width={32} height={156} rx={16} fill={skin} {...S} />
      <rect x={-17} y={-8} width={34} height={SLEEVE[kind]} rx={16} fill={top} {...S} />
      <circle cx={0} cy={152} r={19} fill={skin} {...S} />
      {extra}
    </g>
  );

  const scratchMark = kind === 'sumaiya' && scratch > 0 && (
    <g>
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${-11 + i * 10} ${96 + i * 3} Q${-6 + i * 10} 116 ${-13 + i * 11} ${140}`}
          pathLength={1} strokeDasharray={1} strokeDashoffset={1 - scratch} stroke="#c62828" strokeWidth={5}
          fill="none" strokeLinecap="round" />
      ))}
      {scratch > 0.8 && <circle cx={-2} cy={142} r={3.5} fill="#c62828" />}
    </g>
  );

  const momoBox = momo && (
    <g transform="translate(0 150)">
      <rect x={-30} y={-6} width={60} height={46} rx={8} fill="#fff" {...S} />
      <rect x={-30} y={-6} width={60} height={14} rx={6} fill="#e53935" {...S} />
      <path d="M-14 32 Q0 14 14 32 Z" fill="#ffe0b2" stroke={OUT} strokeWidth={2} />
    </g>
  );

  const eye = (cx: number) => {
    const white = infect > 0.15 ? mix('#ffffff', '#e4e9d6', Math.min(1, infect)) : '#fff';
    const ox = look[0] * 8, oy = look[1] * 8;
    return (
      <g transform={`translate(${cx} -8) scale(1 ${blink ? 0.1 : 1})`}>
        <ellipse rx={z ? 21 : 20} ry={z ? 24 : 23} fill={white} {...S} />
        <circle cx={ox} cy={oy} r={kind === 'mystery' ? 11 : 10} fill={mix('#222222', '#e4e9d6', infect)} />
        {infect < 0.6 && <circle cx={ox + 3} cy={oy - 4} r={3} fill="#fff" />}
        {infect > 0.4 && <circle cx={ox} cy={oy} r={11} fill="none" stroke="#b9c1ae" strokeWidth={2} opacity={infect} />}
        {infect > 0.7 && <path d="M-18 -4 L-9 0 M18 4 L9 0" stroke="#b86a6a" strokeWidth={1.5} opacity={infect} />}
      </g>
    );
  };

  const mouth = () => {
    if (z) {
      const o = 6 + Math.sin((fr + sd) / 5) * 4;
      return (
        <g transform="translate(0 2)">
          <path d={`M-28 50 Q0 ${84 + o} 28 50 Z`} fill="#4a1818" {...S} />
          <path d="M-20 51 L-14 61 L-8 51 M-2 51 L4 62 L10 51 M12 51 L17 59 L22 51" fill="none" stroke="#e6e6d0" strokeWidth={3} />
        </g>
      );
    }
    if (shape === 1) return <ellipse cx={0} cy={50} rx={16} ry={9} fill="#6e2323" {...S} />;
    if (shape === 2) return (
      <g><ellipse cx={0} cy={52} rx={21} ry={19} fill="#6e2323" {...S} /><ellipse cx={0} cy={62} rx={11} ry={6} fill="#e57b8a" /></g>
    );
    if (e === 'shock') return <ellipse cx={0} cy={54} rx={12} ry={16} fill="#6e2323" {...S} />;
    if (e === 'laugh') return (
      <g><path d="M-30 42 Q0 92 30 42 Z" fill="#6e2323" {...S} /><ellipse cx={0} cy={66} rx={12} ry={6} fill="#e57b8a" /></g>
    );
    return <path d={MOUTH[e]} fill="none" {...S} strokeWidth={3.5} />;
  };

  const [ba, bd] = BROW[e];
  const browFill = kind === 'prabha' ? '#2a1a14' : '#1d1d1d';
  const face = (
    <g transform={`translate(0 -495) scale(${fs})`}>
      {(kind === 'mystery' || z || infect > 0.5) && (
        <g><ellipse cx={-34} cy={20} rx={22} ry={8} fill="#6a5f73" opacity={0.35} /><ellipse cx={34} cy={20} rx={22} ry={8} fill="#6a5f73" opacity={0.35} /></g>
      )}
      {eye(-34)}{eye(34)}
      {kind === 'ahana' && (
        <g fill="#bfe6ff" fillOpacity={0.18} stroke={OUT} strokeWidth={3.5}>
          <circle cx={-34} cy={-8} r={31} /><circle cx={34} cy={-8} r={31} />
          <path d="M-3 -10 Q0 -16 3 -10" fill="none" /><path d="M-65 -12 L-84 -18 M65 -12 L84 -18" fill="none" />
        </g>
      )}
      <g transform={`translate(-34 ${-48 + bd}) rotate(${ba})`}><rect x={-22} y={-3.5} width={44} height={7} rx={3.5} fill={browFill} /></g>
      <g transform={`translate(34 ${-48 + bd}) rotate(${-ba})`}><rect x={-22} y={-3.5} width={44} height={7} rx={3.5} fill={browFill} /></g>
      {(e === 'happy' || e === 'nervous' || e === 'laugh') && (
        <g><ellipse cx={-56} cy={28} rx={14} ry={8} fill="#ff8fa3" opacity={0.35} /><ellipse cx={56} cy={28} rx={14} ry={8} fill="#ff8fa3" opacity={0.35} /></g>
      )}
      {mouth()}
      {sweat && (
        <path transform={`translate(70 ${-62 + Math.sin(fr / 6) * 4})`} d="M0 0 C10 16 14 26 0 34 C-14 26 -10 16 0 0 Z" fill="#8ad4ff" stroke={OUT} strokeWidth={2} />
      )}
    </g>
  );

  // ---------- পিছনের চুল (শরীরের আগে) ----------
  const backHair =
    kind === 'sumaiya' ? (
      <path d="M-94 -500 C-104 -610 104 -610 94 -500 L106 -372 Q0 -346 -106 -372 Z" fill={hair} {...S} />
    ) : kind === 'prabha' ? (
      <g fill={hair} {...S}>
        {[-190, -170, -150, -130, -110, -90, -70, -50, -30, -10, 10].map((d, i) => (
          <circle key={i} cx={Math.cos((d * Math.PI) / 180) * 90} cy={-495 + Math.sin((d * Math.PI) / 180) * 94} r={34} />
        ))}
        <circle cx={-100} cy={-450} r={30} /><circle cx={-106} cy={-408} r={28} />
        <circle cx={100} cy={-450} r={30} /><circle cx={106} cy={-408} r={28} />
      </g>
    ) : null;

  // ---------- ধড় ----------
  const torso =
    kind === 'sumaiya' ? (
      <g>
        <path d="M-72 -380 Q-72 -412 -40 -412 L40 -412 Q72 -412 72 -380 L88 -128 Q0 -112 -88 -128 Z" fill={top} {...S} />
        <path d="M-86 -150 Q0 -134 86 -150" fill="none" stroke="#e6a93a" strokeWidth={8} />
        <path d="M-24 -410 Q0 -380 24 -410" fill={skin} {...S} />
        <path d="M-52 -410 L72 -228" stroke="#7a4b2a" strokeWidth={9} fill="none" strokeLinecap="round" />
        <rect x={46} y={-232} width={66} height={54} rx={12} fill="#b07a45" {...S} />
        <path d="M46 -214 Q79 -200 112 -214" fill="none" stroke={OUT} strokeWidth={2} />
      </g>
    ) : kind === 'ahana' ? (
      <rect x={-72} y={-412} width={144} height={254} rx={46} fill={top} {...S} />
    ) : kind === 'prabha' ? (
      <g>
        <rect x={-74} y={-412} width={148} height={262} rx={46} fill={top} {...S} />
        <rect x={-74} y={-176} width={148} height={26} rx={13} fill="#c82f2f" {...S} />
        <path d="M-50 -262 L50 -262 L58 -196 L-58 -196 Z" fill="#cf3434" {...S} />
        <path d="M-62 -412 Q0 -350 62 -412 Q40 -440 0 -438 Q-40 -440 -62 -412 Z" fill="#c82f2f" {...S} />
        <path d="M-14 -392 L-16 -330 M14 -392 L16 -330" stroke="#fff" strokeWidth={4} />
      </g>
    ) : kind === 'mystery' ? (
      <g>
        <rect x={-72} y={-412} width={144} height={254} rx={40} fill={top} {...S} />
        <rect x={-52} y={-340} width={34} height={22} fill="#e8e8e8" {...S} />
        <path d="M-24 -410 Q0 -384 24 -410" fill={skin} {...S} />
      </g>
    ) : (
      <g>
        <path d="M-72 -380 Q-72 -412 -40 -412 L40 -412 Q72 -412 72 -380 L76 -150 L56 -170 L40 -140 L18 -168 L0 -136 L-20 -170 L-44 -138 L-60 -168 L-76 -146 Z" fill={top} {...S} />
        <rect x={12} y={-330} width={36} height={30} fill="#3d3a33" {...S} transform="rotate(8 30 -315)" />
        <ellipse cx={-30} cy={-250} rx={26} ry={14} fill="#000" opacity={0.15} />
        <path d="M-24 -410 Q0 -384 24 -410" fill={skin} {...S} />
      </g>
    );

  // ---------- হিজাব (অহনা) ----------
  const hijab = kind === 'ahana' && (
    <g>
      <path d="M0 -604 C96 -604 120 -520 114 -455 C110 -410 132 -385 142 -340 L-142 -340 C-132 -385 -110 -410 -114 -455 C-120 -520 -96 -604 0 -604 Z" fill="#3fa166" {...S} />
      <path d="M-60 -380 Q-30 -350 -20 -340 M60 -380 Q30 -350 20 -340" stroke="#2c7a4b" strokeWidth={3} fill="none" />
    </g>
  );

  // ---------- মাথা ----------
  const CAP = 'M-90 -478 C-98 -630 98 -630 90 -478 ';
  const frontHair =
    kind === 'sumaiya' ? (
      // মাথার ওপরের পুরোটা ঢাকা (স্ক্যাল্প দেখা যাবে না) + মাঝখানে সিঁথি, কপালের দুপাশে ঝুলে থাকা চুল
      <path d={CAP + 'C92 -520 70 -532 52 -536 Q24 -548 0 -556 Q-24 -548 -52 -536 C-70 -532 -92 -520 -90 -478 Z'} fill={hair} {...S} />
    ) : kind === 'prabha' ? (
      <g fill={hair} {...S}>
        <path d={CAP + 'C92 -520 76 -536 56 -544 Q20 -556 0 -560 Q-20 -556 -56 -544 C-76 -536 -92 -520 -90 -478 Z'} />
        {[-62, -36, -10, 10, 36, 62].map((cx, i) => <circle key={i} cx={cx} cy={-546 - (62 - Math.abs(cx)) * 0.28} r={22} />)}
        <circle cx={-44} cy={-588} r={24} /><circle cx={0} cy={-596} r={26} /><circle cx={44} cy={-588} r={24} />
      </g>
    ) : kind === 'mystery' || z ? (
      <g>
        <path d={CAP + 'L78 -520 L62 -534 L44 -522 L28 -544 L8 -526 L-12 -546 L-30 -524 L-50 -542 L-66 -526 L-80 -520 Z'} fill={hair} {...S} />
        <path d="M-88 -540 L-100 -584 L-64 -562 L-60 -616 L-30 -574 L-8 -624 L12 -576 L40 -616 L50 -566 L84 -598 L82 -540 Z" fill={hair} {...S} />
        {z && <path d="M-88 -505 L-102 -440 L-82 -472 Z M88 -505 L100 -446 L80 -474 Z" fill={hair} {...S} />}
      </g>
    ) : null;

  const head = (
    <g transform={`rotate(${headTilt} 0 -415)`}>
      {kind !== 'ahana' && (
        <g><circle cx={-85} cy={-492} r={15} fill={skin} {...S} /><circle cx={85} cy={-492} r={15} fill={skin} {...S} /></g>
      )}
      {kind === 'ahana' ? (
        <g>
          <ellipse cx={0} cy={-492} rx={74} ry={84} fill={skin} {...S} />
          <path d="M-77 -525 C-71 -596 71 -596 77 -525 C52 -566 -52 -566 -77 -525 Z" fill="#3fa166" {...S} />
        </g>
      ) : (
        <ellipse cx={0} cy={-495} rx={86} ry={90} fill={skin} {...S} />
      )}
      {frontHair}
      {face}
    </g>
  );

  return (
    <g transform={`translate(${x + tx} ${y + ty + bob + rb}) scale(${flip ? -s : s} ${s})`}>
      <g transform={`translate(0 ${-75 * lie}) rotate(${-90 * lie + tilt})`}>
        {backHair}
        {leg(-30, legRot)}{leg(30, -legRot)}
        {torso}
        {hijab}
        {arm(-75, aR, scratchMark)}
        {arm(75, -aL, momoBox)}
        {head}
      </g>
    </g>
  );
};
