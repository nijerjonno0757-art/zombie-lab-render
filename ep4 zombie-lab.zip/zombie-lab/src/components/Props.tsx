import React from 'react';
import {COLORS, NAMES, OUT, SW, Who} from '../config';
import {fontFamily} from '../font';
import {pop, ramp} from '../lib/anim';

const S = {stroke: OUT, strokeWidth: SW, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
type IP = {x?: number; y?: number; s?: number; rot?: number; o?: number};
const tf = ({x = 0, y = 0, s = 1, rot = 0}: IP) => `translate(${x} ${y}) rotate(${rot}) scale(${s})`;

/** মস্তিষ্ক আইকন (~১০০×৮০, মাঝখানে অরিজিন) */
export const Brain: React.FC<IP> = (p) => (
  <g transform={tf(p)} opacity={p.o ?? 1}>
    <g transform="translate(-50 -37)">
      <path d="M50 8 C36 -2 14 6 14 26 C2 30 2 52 16 56 C16 70 36 76 50 66 C64 76 84 70 84 56 C98 52 98 30 86 26 C86 6 64 -2 50 8 Z" fill="#f6a5c0" {...S} />
      <path d="M50 8 L50 66" fill="none" {...S} />
      <path d="M26 30 Q36 24 40 34 M74 30 Q64 24 60 34 M28 48 Q38 42 42 52 M72 48 Q62 42 58 52" fill="none" stroke="#d0708f" strokeWidth={3} strokeLinecap="round" />
    </g>
  </g>
);

export const Momo: React.FC<IP> = (p) => (
  <g transform={tf(p)} opacity={p.o ?? 1}>
    <path d="M-45 18 Q0 -42 45 18 Q0 30 -45 18 Z" fill="#fff3e0" {...S} />
    <path d="M-22 0 L-18 18 M-8 -8 L-6 20 M8 -8 L6 20 M22 0 L16 18" fill="none" stroke={OUT} strokeWidth={2} />
    <path d="M-12 -40 Q-20 -52 -10 -62 M6 -40 Q-2 -52 8 -62 M22 -36 Q14 -46 22 -56" fill="none" stroke="#fff" strokeWidth={4} strokeLinecap="round" opacity={0.8} />
  </g>
);

export const QMark: React.FC<IP> = (p) => (
  <g transform={tf(p)} opacity={p.o ?? 1}>
    <circle r={46} fill="#ffd23f" {...S} />
    <text textAnchor="middle" y={28} fontSize={80} fontWeight={700} fontFamily={fontFamily} fill={OUT}>?</text>
  </g>
);

export const Warn: React.FC<IP & {fill?: string}> = (p) => (
  <g transform={tf(p)} opacity={p.o ?? 1}>
    <path d="M0 -44 L46 36 L-46 36 Z" fill={p.fill ?? '#ffd23f'} {...S} />
    <rect x={-4.5} y={-16} width={9} height={32} rx={4} fill={OUT} />
    <circle cy={26} r={5} fill={OUT} />
  </g>
);

export const MomoBox: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(0.9)`}>
    <rect x={-30} y={-24} width={60} height={46} rx={8} fill="#fff" {...S} />
    <rect x={-30} y={-24} width={60} height={14} rx={6} fill="#e53935" {...S} />
    <path d="M-14 14 Q0 -4 14 14 Z" fill="#ffe0b2" stroke={OUT} strokeWidth={2} />
  </g>
);

/** পরিচয় পিল-ব্যাজ (ওয়ার্ল্ড স্পেসে, মাথার ওপর) */
export const NameBadge: React.FC<{who: Who; x: number; y: number; t: number; at: number; until: number}> = ({who, x, y, t, at, until}) => {
  if (t < at || t > until) return null;
  const sc = pop(t, at, 0.3) * (1 - ramp(t, until - 0.2, until));
  const dark = who === 'sumaiya';
  return (
    <g transform={`translate(${x} ${y - Math.sin(t * 4) * 3}) scale(${sc})`}>
      <rect x={-100} y={-31} width={200} height={62} rx={31} fill={COLORS[who]} {...S} />
      <text textAnchor="middle" y={13} fontSize={38} fontWeight={700} fontFamily={fontFamily} fill={dark ? OUT : '#fff'}>{NAMES[who]}</text>
    </g>
  );
};
