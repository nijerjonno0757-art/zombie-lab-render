import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CAPS, CARDS, COLORS, COUNT_START, FPS, H, LINES, OUT, W, Who, countRemain, overlayActive, pad2, toBn} from '../config';
import {fontFamily} from '../font';
import {back, clamp, eout, ramp, win} from '../lib/anim';
import {Cam, project, useT} from '../lib/camera';
import {Brain, Warn} from './Props';

const SHADOW = '-4px -4px 0 #111, 4px -4px 0 #111, -4px 4px 0 #111, 4px 4px 0 #111, 0 -5px 0 #111, 0 5px 0 #111, -5px 0 0 #111, 5px 0 0 #111, 0 8px 14px rgba(0,0,0,.6)';

/** স্পিচ কলআউট বাবল — স্ক্রিন-স্পেসে, বক্তার মাথার দিকে লেজ */
export const Bubble: React.FC<{cam: Cam; anchor: (w: Who) => [number, number]}> = ({cam, anchor}) => {
  const t = useT();
  const line = LINES.find((l) => t >= l.from && t < l.to);
  if (!line) return null;
  const [hx, hy] = anchor(line.who);
  const [sx, sy] = project(cam, hx, hy);
  const age = t - line.from, left = line.to - t;
  const sc = Math.max(0.01, back(ramp(age, 0, 0.22))) * (left < 0.1 ? Math.max(0, left / 0.1) : 1);
  const bw = Math.min(880, Math.ceil(line.text.length * 60 * 0.52) + 90);
  const cx = clamp(sx, 50 + bw / 2, W - 50 - bw / 2);
  const bottom = clamp(sy - 70, 430, 1180);
  const tipX = clamp(sx, 80, W - 80);
  const tipY = Math.max(sy - 6, bottom + 46);
  const bx = clamp(tipX, cx - bw / 2 + 70, cx + bw / 2 - 70);
  return (
    <div style={{position: 'absolute', inset: 0, transformOrigin: `${tipX}px ${tipY}px`, transform: `scale(${sc})`}}>
      <div style={{position: 'absolute', left: cx - bw / 2, width: bw, bottom: H - bottom, boxSizing: 'border-box', background: '#fff',
        border: `6px solid ${OUT}`, borderRadius: 46, padding: '28px 36px', fontFamily, fontWeight: 700, fontSize: 60, lineHeight: 1.25,
        textAlign: 'center', color: OUT}}>
        {line.text}
      </div>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <path d={`M${bx - 30} ${bottom - 3} L${tipX} ${tipY} L${bx + 30} ${bottom - 3}`} fill="#fff" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
        <rect x={bx - 25} y={bottom - 10} width={50} height={12} fill="#fff" />
      </svg>
    </div>
  );
};

/** নিচের ওভারলে ক্যাপশন — কলআউট/কার্ড থাকলে দেখায় না */
export const Caption: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const c = CAPS.find(([a, b]) => t >= a && t < b);
  if (!c || overlayActive(t)) return null;
  const [a, b, txt] = c;
  const inP = eout(ramp(t, a, a + 0.18));
  const outP = 1 - ramp(t, b - 0.08, b);
  const plain = txt.replace(/\*\*/g, '');
  const fs = clamp(940 / (plain.length * 0.56), 40, 64);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 250, display: 'flex', justifyContent: 'center',
      opacity: inP * outP, transform: `translateY(${(1 - inP) * 28}px)`}}>
      <div style={{fontFamily, fontWeight: 700, fontSize: fs, color: '#fff', whiteSpace: 'nowrap', textShadow: SHADOW}}>
        {txt.split('**').map((p, i) => <span key={i} style={i % 2 ? {color: '#ffd23f'} : undefined}>{p}</span>)}
      </div>
    </div>
  );
};

const center: React.CSSProperties = {position: 'absolute', left: 0, right: 0, display: 'flex', justifyContent: 'center'};

/** লোকেশন পিল, কিওয়ার্ড কার্ড, স্ট্যাম্প, কাউন্টডাউন কার্ড */
export const Cards: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  return (
    <>
      {CARDS.map((c) => {
        if (t < c.from || t >= c.to) return null;
        const v = win(t, c.from, c.to, 0.3, 0.25);
        const pp = Math.max(0.01, back(ramp(t, c.from, c.from + 0.3)));
        if (c.kind === 'loc')
          return (
            <div key="loc" style={{...center, top: 170, opacity: v, transform: `translateY(${(1 - v) * -30}px)`}}>
              <div style={{background: '#0e1822', border: `4px solid ${OUT}`, borderRadius: 60, padding: '16px 40px', color: '#fff',
                fontFamily, fontWeight: 700, fontSize: 46, display: 'flex', gap: 16, alignItems: 'center'}}>
                <span style={{width: 22, height: 22, borderRadius: '50%', background: '#ffd23f'}} />ল্যাবরেটরি · গভীর রাত
              </div>
            </div>
          );
        if (c.kind === 'brain')
          return (
            <div key="brain" style={{...center, top: 330, opacity: Math.min(1, v * 1.5)}}>
              <div style={{transform: `scale(${pp})`, background: '#fff', border: `6px solid ${OUT}`, borderRadius: 40, padding: '26px 40px',
                display: 'flex', alignItems: 'center', gap: 28, boxShadow: '0 12px 0 rgba(0,0,0,.35)'}}>
                <svg width={170} height={140}><Brain x={85} y={70} s={1.5 + Math.sin(t * 6) * 0.06} /></svg>
                <div style={{fontFamily, fontWeight: 700, fontSize: 62, color: OUT, lineHeight: 1.2}}>মানুষের <span style={{color: '#d6336c'}}>মস্তিষ্ক<br />নিয়ন্ত্রণ</span></div>
              </div>
            </div>
          );
        if (c.kind === 'fail') {
          const k = 1 + (1 - clamp((t - c.from) / 0.2)) * 1.4;
          return (
            <div key="fail" style={{...center, top: 520, opacity: Math.min(1, (t - c.from) / 0.08)}}>
              <div style={{transform: `rotate(-9deg) scale(${k})`, border: '14px double #d62828', borderRadius: 24, padding: '4px 50px',
                fontFamily, fontWeight: 700, fontSize: 200, color: '#d62828', background: 'rgba(255,255,255,.88)'}}>ব্যর্থ</div>
            </div>
          );
        }
        const rem = countRemain(t);
        return (
          <div key="count" style={{...center, top: 260, opacity: v}}>
            <div style={{transform: `scale(${pp})`, background: '#0b0b0b', border: `8px solid ${Math.sin(t * 10) > 0 ? '#ff3030' : '#8a0000'}`,
              borderRadius: 36, padding: '22px 50px', textAlign: 'center', width: 900, boxSizing: 'border-box'}}>
              <div style={{display: 'flex', gap: 22, alignItems: 'center', justifyContent: 'center'}}>
                <svg width={90} height={80}><Warn x={45} y={42} s={0.95} fill="#ff3b3b" /></svg>
                <div style={{fontFamily, fontWeight: 700, fontSize: 52, color: '#fff'}}>সেলফ ডেসট্রাক্ট সিকোয়েন্স</div>
              </div>
              <div style={{fontFamily, fontWeight: 700, fontSize: 190, color: '#ff3b3b', lineHeight: 1.1}}>
                {toBn(pad2(Math.floor(rem / 60))) + ':' + toBn(pad2(Math.floor(rem % 60)))}
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
};

/** অ্যালার্ম: লাল পালস */
export const Alarm: React.FC<{level: number}> = ({level}) => {
  const t = useT();
  if (level <= 0.01) return null;
  const a = level * (0.3 + 0.25 * Math.sin(t * 9));
  return <div style={{position: 'absolute', inset: 0, pointerEvents: 'none',
    background: `radial-gradient(ellipse at center, rgba(255,0,0,${a * 0.1}) 25%, rgba(255,20,20,${a}) 100%)`}} />;
};

export const Vignette: React.FC = () => (
  <div style={{position: 'absolute', inset: 0, pointerEvents: 'none',
    background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,.45) 100%)'}} />
);
