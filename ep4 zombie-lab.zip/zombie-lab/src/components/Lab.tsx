import React from 'react';
import {COUNT_START, OUT, SW, countRemain, pad2, toBn} from '../config';
import {fontFamily} from '../font';
import {pop, ramp, track} from '../lib/anim';
import {Character} from './Character';
import {Brain, Warn} from './Props';

const S = {stroke: OUT, strokeWidth: SW, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

/** ল্যাবের ব্যাকগ্রাউন্ড: ১০০% এজ-টু-এজ (ওয়ার্ল্ড চওড়া ww, উচ্চতা ১৯২০) */
export const LabBG: React.FC<{ww: number; t: number; shelfX?: number; signX?: number; lights: number[]}> = ({ww, t, shelfX, signX, lights}) => {
  const flick = Math.sin(t * 41) > 0.82 && Math.sin(t * 3.1) > 0 ? 0.35 : 1;
  const beaker = (x: number, y: number, c: string) => (
    <g transform={`translate(${x} ${y})`}>
      <path d="M0 -92 L0 -10 Q0 0 10 0 L42 0 Q52 0 52 -10 L52 -92" fill="#cfe9f2" fillOpacity={0.3} {...S} />
      <path d="M2 -52 L2 -10 Q2 -2 10 -2 L42 -2 Q50 -2 50 -10 L50 -52 Z" fill={c} />
    </g>
  );
  const flask = (x: number, y: number, c: string) => (
    <g transform={`translate(${x} ${y})`}>
      <path d="M18 -92 L18 -60 L-8 -12 Q-10 0 4 0 L48 0 Q62 0 60 -12 L34 -60 L34 -92 Z" fill="#cfe9f2" fillOpacity={0.3} {...S} />
      <path d="M-2 -26 L-8 -12 Q-10 -2 4 -2 L48 -2 Q62 -2 60 -12 L54 -26 Z" fill={c} />
    </g>
  );
  const seams: number[] = [];
  for (let x = 270; x < ww; x += 270) seams.push(x);
  const fl = [1280, 1330, 1400, 1490, 1600, 1740];
  return (
    <g>
      <defs>
        <linearGradient id="wallg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#1b2d3d" /><stop offset="1" stopColor="#25394b" /></linearGradient>
        <linearGradient id="coneg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#dff9ff" stopOpacity="0.18" /><stop offset="1" stopColor="#dff9ff" stopOpacity="0" /></linearGradient>
      </defs>
      <rect width={ww} height={1290} fill="url(#wallg)" />
      {seams.map((x) => <line key={x} x1={x} y1={173} x2={x} y2={1262} stroke="#1d2e3b" strokeWidth={3} />)}
      <rect width={ww} height={170} fill="#101a24" />
      <rect y={165} width={ww} height={8} fill="#0b121a" />
      <rect y={1262} width={ww} height={20} fill="#0f1820" />
      <rect y={1280} width={ww} height={640} fill="#2b3a47" />
      {fl.map((y) => <line key={y} x1={0} y1={y} x2={ww} y2={y} stroke="#35495a" strokeWidth={3} />)}
      {Array.from({length: Math.ceil(ww / 200)}).map((_, i) => <line key={i} x1={i * 200} y1={1280} x2={i * 200} y2={1920} stroke="#35495a" strokeWidth={3} />)}
      {lights.map((cx) => (
        <g key={cx} opacity={flick}>
          <path d={`M${cx - 130} 172 L${cx + 130} 172 L${cx + 330} 1000 L${cx - 330} 1000 Z`} fill="url(#coneg)" />
          <rect x={cx - 130} y={150} width={260} height={24} rx={8} fill="#e8fbff" {...S} />
        </g>
      ))}
      {shelfX !== undefined && (
        <g>
          {beaker(shelfX + 20, 800, '#6be3a0')}{flask(shelfX + 120, 800, '#f08ac0')}{beaker(shelfX + 240, 800, '#ffd36b')}
          <rect x={shelfX} y={800} width={330} height={16} rx={4} fill="#4d6174" {...S} />
          {flask(shelfX + 40, 1000, '#7ab8ff')}{beaker(shelfX + 200, 1000, '#6be3a0')}
          <rect x={shelfX} y={1000} width={330} height={16} rx={4} fill="#4d6174" {...S} />
        </g>
      )}
      {signX !== undefined && (
        <g transform={`translate(${signX} 440)`}>
          <rect x={-90} y={-95} width={180} height={190} rx={14} fill="#2f4558" {...S} />
          <Warn y={-6} s={1.5} />
        </g>
      )}
    </g>
  );
};

/** ডেস্ক + মনিটর; স্ক্রিনের ভেতরের লোকাল মাপ ২৫০×২২০ */
export const Workstation: React.FC<{x: number; screen: React.ReactNode}> = ({x, screen}) => (
  <g>
    <defs><clipPath id="scr"><rect x={x + 15} y={705} width={250} height={220} rx={8} /></clipPath></defs>
    <rect x={x + 6} y={1026} width={24} height={300} fill="#3e5062" {...S} />
    <rect x={x + 276} y={1026} width={24} height={300} fill="#3e5062" {...S} />
    <rect x={x + 40} y={1026} width={200} height={90} rx={6} fill="#45586a" {...S} />
    <rect x={x - 10} y={1000} width={330} height={26} rx={6} fill="#53677a" {...S} />
    <rect x={x + 40} y={984} width={170} height={16} rx={5} fill="#2a3642" {...S} />
    <rect x={x + 125} y={950} width={30} height={40} fill="#2a3642" {...S} />
    <rect x={x} y={690} width={280} height={270} rx={18} fill="#151d25" {...S} />
    <g clipPath="url(#scr)"><g transform={`translate(${x + 15} 705)`}>{screen}</g></g>
    <rect x={x + 15} y={705} width={250} height={220} rx={8} fill="#58e0ff" opacity={0.05} />
  </g>
);

export const DesktopScreen: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect width={250} height={220} fill="#0d3a52" />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <g key={i} transform={`translate(${22 + (i % 3) * 72} ${22 + Math.floor(i / 3) * 70})`}>
        <rect y={-5} width={20} height={7} rx={3} fill="#9cc3d8" /><rect width={46} height={38} rx={5} fill="#cfe6f2" />
      </g>
    ))}
    <rect y={196} width={250} height={24} fill="#0a1f2b" /><rect x={8} y={202} width={14} height={12} rx={3} fill="#58e0ff" />
    {Math.floor(t * 2) % 2 === 0 && <rect x={60} y={170} width={8} height={14} fill="#fff" />}
  </g>
);

/** সিকিউরিটি ক্যামেরা ফিড: ২১.১s-এ চালু, ২৯.৭২s-এ ফ্রিজ (লোকটা গোপন দরজায়) */
export const SecurityFeed: React.FC<{t: number}> = ({t}) => {
  const FREEZE = 29.72;
  const ft = Math.min(t, FREEZE);
  const frozen = t >= FREEZE;
  const walkX = track(ft, [[21.3, 30], [25.6, 160], [26.7, 160], [28.8, 198]]);
  const open = track(ft, [[25.4, 0], [26.4, 1]]);
  const walking = ft > 21.3 && ft < 25.6;
  const sec = 13 + Math.floor(ft - 21);
  return (
    <g>
      <defs>
        <pattern id="scan" width={4} height={4} patternUnits="userSpaceOnUse"><rect width={4} height={1} fill="#000" opacity={0.3} /></pattern>
      </defs>
      <rect width={250} height={220} fill="#10241c" />
      <rect y={160} width={250} height={60} fill="#17332a" />
      <line x1={0} y1={160} x2={250} y2={160} stroke="#2c5a46" strokeWidth={2} />
      <rect x={176} y={46} width={60} height={116} fill="#000" />
      <g transform={`translate(236 0) scale(${1 - 0.85 * open} 1)`}>
        <rect x={-60} y={46} width={60} height={116} fill="#1f4034" stroke="#3f7a5f" strokeWidth={2} />
        <path d="M-40 70 L-28 100 L-44 130" fill="none" stroke="#2c5a46" strokeWidth={2} />
      </g>
      <Character kind="mystery" x={walkX} y={162} s={0.2} float={0} run={walking ? ft * 9 : undefined} runAmp={20} look={ft > 28.5 ? [0, 0] : [1, 0]} />
      <rect width={250} height={220} fill="#00ff88" opacity={0.07} />
      <rect width={250} height={220} fill="url(#scan)" />
      <text x={12} y={22} fontSize={12} fontFamily="monospace" fill="#9fffd0">CAM 03  02:47:{pad2(sec)}</text>
      {!frozen && Math.floor(t * 2) % 2 === 0 && <circle cx={228} cy={18} r={6} fill="#ff3030" />}
      {frozen && (
        <g>
          <rect x={(Math.sin(t * 20) + 1) * 3} y={(t * 70) % 220} width={250} height={5} fill="#fff" opacity={0.18} />
          <rect x={104} y={86} width={14} height={44} rx={3} fill="#fff" opacity={0.9} /><rect x={132} y={86} width={14} height={44} rx={3} fill="#fff" opacity={0.9} />
        </g>
      )}
    </g>
  );
};

/** ফাইল-খোলা স্ক্রিন (৩৪.৬৬s-এ পপ-আপ); ৪৪.২৬s-এ লাল এরর */
export const FileScreen: React.FC<{t: number}> = ({t}) => {
  const p = Math.max(0.01, pop(t, 34.66, 0.5));
  const widths = [100, 80, 110, 70, 95, 60];
  return (
    <g>
      <rect width={250} height={220} fill="#0d3a52" />
      <g transform={`translate(125 110) scale(${p}) translate(-125 -110)`}>
        <rect x={14} y={14} width={222} height={190} rx={8} fill="#f4f7fa" {...S} />
        <rect x={14} y={14} width={222} height={24} rx={8} fill="#2f4a63" />
        {[0, 1, 2].map((i) => <circle key={i} cx={30 + i * 14} cy={26} r={4} fill={['#ff6b6b', '#ffd23f', '#6be3a0'][i]} />)}
        {widths.map((w, i) => <rect key={i} x={28} y={52 + i * 16} width={w} height={8} rx={3} fill="#c5d0d8" />)}
        <g opacity={ramp(t, 38.2, 38.8)}><Brain x={185} y={96} s={1.0} /></g>
        <g opacity={ramp(t, 44.26, 44.5)}>
          <rect x={14} y={168} width={222} height={36} rx={6} fill="#d62828" />
          <path d="M112 176 L138 196 M138 176 L112 196" stroke="#fff" strokeWidth={6} strokeLinecap="round" />
        </g>
      </g>
    </g>
  );
};

export const CountScreen: React.FC<{t: number}> = ({t}) => {
  const rem = countRemain(t);
  const m = Math.floor(rem / 60), s = Math.floor(rem % 60);
  return (
    <g>
      <rect width={250} height={220} fill={Math.sin(t * 9) > 0 ? '#3a0000' : '#160000'} />
      <Warn x={125} y={44} s={0.7} fill="#ff3b3b" />
      <text x={125} y={128} textAnchor="middle" fontSize={64} fontWeight={700} fontFamily={fontFamily} fill="#ff3b3b">{toBn(pad2(m)) + ':' + toBn(pad2(s))}</text>
      <text x={125} y={168} textAnchor="middle" fontSize={15} fontFamily="monospace" fill="#ffb3b3" letterSpacing={3}>SELF DESTRUCT</text>
    </g>
  );
};
export const screenAt2 = (t: number) =>
  t < 34.66 ? <SecurityFeed t={t} /> : t < COUNT_START ? <FileScreen t={t} /> : <CountScreen t={t} />;

/** ধাতব দরজা (hinge ডানে); open ০=বন্ধ ১=খোলা। children = দরজার বাইরের দৃশ্য (ক্লিপড) */
export const Door: React.FC<{x: number; open: number; shake?: number; children?: React.ReactNode}> = ({x, open, shake = 0, children}) => {
  const dw = 440, top = 540, bot = 1300;
  const sc = 1 - open * 0.9;
  return (
    <g>
      <defs>
        <clipPath id="doorway"><rect x={x} y={top} width={dw} height={bot - top} /></clipPath>
        <linearGradient id="night" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0b1230" /><stop offset="0.7" stopColor="#233a52" /><stop offset="1" stopColor="#1a2b22" /></linearGradient>
      </defs>
      <rect x={x - 26} y={top - 26} width={dw + 52} height={bot - top + 26} rx={10} fill="#3b4856" {...S} />
      <g clipPath="url(#doorway)">
        <rect x={x} y={top} width={dw} height={bot - top} fill="url(#night)" />
        <circle cx={x + 90} cy={top + 110} r={46} fill="#f3f0d0" />
        <rect x={x} y={1130} width={dw} height={bot - 1130} fill="#1b2a20" />
        {open > 0.02 && children}
      </g>
      <g transform={`translate(${x + dw + shake} 0) scale(${sc} 1)`}>
        <rect x={-dw} y={top} width={dw} height={bot - top} fill="#8a96a3" {...S} />
        {[700, 900, 1100].map((y) => <rect key={y} x={-dw + 24} y={y} width={dw - 48} height={14} rx={5} fill="#6f7b88" {...S} />)}
        {[0, 1, 2, 3].map((i) => <circle key={i} cx={-dw + 26 + (i % 2) * (dw - 52)} cy={600 + Math.floor(i / 2) * 640} r={7} fill="#5c6773" {...S} />)}
        <circle cx={-dw + 44} cy={930} r={16} fill="#d9dde2" {...S} />
      </g>
      <rect x={x - 26} y={top - 74} width={dw + 52} height={40} fill="#ffd23f" {...S} />
      {[0, 1, 2, 3, 4, 5, 6].map((i) => (
        <path key={i} d={`M${x - 20 + i * 70} ${top - 74} l24 0 l-22 40 l-24 0 Z`} fill={OUT} />
      ))}
    </g>
  );
};
