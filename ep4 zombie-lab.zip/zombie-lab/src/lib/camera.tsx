import React, {createContext, useContext} from 'react';
import {Easing, Sequence, useCurrentFrame} from 'remotion';
import {FPS, H, W} from '../config';

const TimeCtx = createContext(0);

/** অ্যাবসোলিউট সময় (সেকেন্ড) — সিনের ভেতরেও */
export const useT = () => {
  const fr = useCurrentFrame();
  return useContext(TimeCtx) + fr / FPS;
};

export const SceneWrap: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => {
  const f0 = Math.round(from * FPS);
  return (
    <Sequence from={f0} durationInFrames={Math.round(to * FPS) - f0}>
      <TimeCtx.Provider value={f0 / FPS}>{children}</TimeCtx.Provider>
    </Sequence>
  );
};

// ===== ক্যামেরা =====
export type Key = {t: number; x: number; y: number; z: number; ease?: 'io' | 'out' | 'linear'};
export type Shake = {from: number; to: number; amp: number};
export type Cam = {x: number; y: number; z: number; sx: number; sy: number};

export function camAt(keys: Key[], t: number, worldW: number, shakes: Shake[] = []): Cam {
  let a = keys[0], b = keys[0];
  if (t >= keys[keys.length - 1].t) a = b = keys[keys.length - 1];
  else if (t > keys[0].t) {
    for (let i = 0; i < keys.length - 1; i++) {
      if (t >= keys[i].t && t < keys[i + 1].t) { a = keys[i]; b = keys[i + 1]; break; }
    }
  }
  const p = a === b ? 0 : (t - a.t) / (b.t - a.t);
  const e = b.ease === 'linear' ? p : b.ease === 'out' ? Easing.out(Easing.cubic)(p) : Easing.inOut(Easing.cubic)(p);
  const z = a.z + (b.z - a.z) * e;
  let x = a.x + (b.x - a.x) * e;
  let y = a.y + (b.y - a.y) * e;
  const hx = W / 2 / z, hy = H / 2 / z; // দৃশ্যের বাইরে যেন না যায়
  x = Math.min(Math.max(x, hx), worldW - hx);
  y = Math.min(Math.max(y, hy), H - hy);
  let sx = 0, sy = 0;
  for (const s of shakes) {
    if (t >= s.from && t <= s.to) {
      const env = Math.min(Math.min(1, (t - s.from) / 0.05), 1 - Math.max(0, (t - (s.to - 0.3)) / 0.3));
      const k = s.amp * env;
      sx += Math.sin(t * 61) * k + Math.sin(t * 37 + 1) * k * 0.5;
      sy += Math.cos(t * 53) * k * 0.8;
    }
  }
  return {x, y, z, sx, sy};
}

export const useCam = (keys: Key[], worldW: number, shakes?: Shake[]) => camAt(keys, useT(), worldW, shakes);

export const CamView: React.FC<{cam: Cam; children: React.ReactNode}> = ({cam, children}) => (
  <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden'}}>
    <div
      style={{
        position: 'absolute', left: 0, top: 0, transformOrigin: '0 0',
        transform: `translate(${W / 2 - cam.x * cam.z + cam.sx}px, ${H / 2 - cam.y * cam.z + cam.sy}px) scale(${cam.z})`,
      }}
    >
      {children}
    </div>
  </div>
);

/** ওয়ার্ল্ড পয়েন্ট → স্ক্রিন পয়েন্ট (শেক ছাড়া) */
export const project = (cam: Cam, wx: number, wy: number): [number, number] => [
  W / 2 + (wx - cam.x) * cam.z,
  H / 2 + (wy - cam.y) * cam.z,
];
