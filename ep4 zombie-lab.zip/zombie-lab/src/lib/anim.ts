import {Easing} from 'remotion';
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const ramp = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const eio = (p: number) => Easing.inOut(Easing.cubic)(p);
export const eout = (p: number) => Easing.out(Easing.cubic)(p);
export const back = (p: number) => {
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};
/** ০→১ ওভারশুটসহ পপ-ইন */
export const pop = (t: number, at: number, dur = 0.3) => back(ramp(t, at, at + dur));
/** উইন্ডো [a,b]-তে ফেড-ইন/আউটসহ ০..১ */
export const win = (t: number, a: number, b: number, fi = 0.25, fo = 0.2) =>
  Math.min(ramp(t, a, a + fi), 1 - ramp(t, b - fo, b));
/** কিফ্রেম ট্র্যাক: [সময়, মান] — মাঝখানে ইজড */
export const track = (t: number, pts: [number, number][]) => {
  if (t <= pts[0][0]) return pts[0][1];
  const last = pts[pts.length - 1];
  if (t >= last[0]) return last[1];
  for (let i = 0; i < pts.length - 1; i++) {
    const [t0, v0] = pts[i], [t1, v1] = pts[i + 1];
    if (t >= t0 && t < t1) return lerp(v0, v1, eio((t - t0) / (t1 - t0)));
  }
  return last[1];
};
