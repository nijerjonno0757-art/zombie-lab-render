import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {SCENES} from './config';
import {SceneWrap} from './lib/camera';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Caption, Cards, Vignette} from './components/Overlays';

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    <Audio src={staticFile('voice.mp3')} />
    <SceneWrap from={SCENES.s1[0]} to={SCENES.s1[1]}><Scene1 /></SceneWrap>
    <SceneWrap from={SCENES.s2[0]} to={SCENES.s2[1]}><Scene2 /></SceneWrap>
    <SceneWrap from={SCENES.s3[0]} to={SCENES.s3[1]}><Scene3 /></SceneWrap>
    <SceneWrap from={SCENES.s4[0]} to={SCENES.s4[1]}><Scene4 /></SceneWrap>
    <Vignette />
    <Cards />
    <Caption />
  </AbsoluteFill>
);
